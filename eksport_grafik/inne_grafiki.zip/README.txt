POZOSTALE GRAFIKI: duze obrazy (kociol, bufor, grzejnik, CWU), tla, naglowek, kafle, przyciski szerokie, paski, tory suwakow, cienkie linie i separatory.
Zrodlo: bitmapy z firmware FW2213TK (RGBA, z kanalem alfa), id = numer bitmapy w firmware (analiza_archiwum/.../bitmaps/manifest.csv).
