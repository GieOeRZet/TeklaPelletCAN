IKONY: bitmapy do 64 px (dluzszy bok), oba boki >= 10 px - ikony kafli, menu, przyciski ikonowe, strzalki, znaczniki.
Zrodlo: bitmapy z firmware FW2213TK (RGBA, z kanalem alfa), id = numer bitmapy w firmware (analiza_archiwum/.../bitmaps/manifest.csv).
